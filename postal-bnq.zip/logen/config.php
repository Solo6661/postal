<?php

$METRI_TOKEN = "https://api.telegram.org/bot1165001463:AAF1yeigNLQyDk3RtKg3elXdanc0XwCYpYM";

$chat_id = "-1001187111074";

$sms_reload = '3';

?>